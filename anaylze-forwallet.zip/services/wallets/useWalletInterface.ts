import { useState, useEffect, useContext } from "react";
import { MetamaskContext } from "../../contexts/MetamaskContext";
import { WalletConnectContext } from "../../contexts/WalletConnectContext";
import { metamaskWallet } from "./metamask/metamaskClient";
import { walletConnectWallet } from "./walletconnect/walletConnectClient";

type WalletData = {
  accountId: string | null;
  walletInterface: typeof metamaskWallet | typeof walletConnectWallet | null;
};

export const useWalletInterface = () => {
  const metamaskCtx = useContext(MetamaskContext);
  const walletConnectCtx = useContext(WalletConnectContext);

  const [walletData, setWalletData] = useState<WalletData>({
    accountId: null,
    walletInterface: null,
  });

  useEffect(() => {
    if (typeof window !== "undefined") { // ✅ Prevents SSR crash
      if (metamaskCtx.metamaskAccountAddress) {
        setWalletData({
          accountId: metamaskCtx.metamaskAccountAddress,
          walletInterface: metamaskWallet,
        });
      } else if (walletConnectCtx.accountId) {
        setWalletData({
          accountId: walletConnectCtx.accountId,
          walletInterface: walletConnectWallet,
        });
      }
    }
  }, [metamaskCtx.metamaskAccountAddress, walletConnectCtx.accountId]);

  return walletData;
};
